﻿namespace security_test {
    partial class Form3 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose ( bool disposing ) {
            if ( disposing && ( components != null ) ) {
                components.Dispose();
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent () {
            this.myLabelQuestion = new System.Windows.Forms.Label();
            this.myLabelReplie1 = new System.Windows.Forms.Label();
            this.myButtonNext = new System.Windows.Forms.Button();
            this.myLabelReplie2 = new System.Windows.Forms.Label();
            this.myLabelReplie3 = new System.Windows.Forms.Label();
            this.myLabelReplie4 = new System.Windows.Forms.Label();
            this.myLabelPercent1 = new System.Windows.Forms.Label();
            this.myLabelPercent2 = new System.Windows.Forms.Label();
            this.myLabelPercent3 = new System.Windows.Forms.Label();
            this.myLabelPercent4 = new System.Windows.Forms.Label();
            this.myLabelResultHack = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // myLabelQuestion
            // 
            this.myLabelQuestion.Dock = System.Windows.Forms.DockStyle.Top;
            this.myLabelQuestion.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.myLabelQuestion.Location = new System.Drawing.Point(0, 0);
            this.myLabelQuestion.Name = "myLabelQuestion";
            this.myLabelQuestion.Size = new System.Drawing.Size(633, 57);
            this.myLabelQuestion.TabIndex = 0;
            this.myLabelQuestion.Text = "label1";
            this.myLabelQuestion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // myLabelReplie1
            // 
            this.myLabelReplie1.Location = new System.Drawing.Point(100, 65);
            this.myLabelReplie1.Name = "myLabelReplie1";
            this.myLabelReplie1.Size = new System.Drawing.Size(500, 60);
            this.myLabelReplie1.TabIndex = 1;
            this.myLabelReplie1.Text = "label2";
            // 
            // myButtonNext
            // 
            this.myButtonNext.Location = new System.Drawing.Point(438, 345);
            this.myButtonNext.Name = "myButtonNext";
            this.myButtonNext.Size = new System.Drawing.Size(183, 55);
            this.myButtonNext.TabIndex = 5;
            this.myButtonNext.Text = "Suivant";
            this.myButtonNext.UseVisualStyleBackColor = true;
            this.myButtonNext.Click += new System.EventHandler(this.myButtonNext_Click);
            // 
            // myLabelReplie2
            // 
            this.myLabelReplie2.Location = new System.Drawing.Point(100, 125);
            this.myLabelReplie2.Name = "myLabelReplie2";
            this.myLabelReplie2.Size = new System.Drawing.Size(500, 60);
            this.myLabelReplie2.TabIndex = 6;
            this.myLabelReplie2.Text = "label3";
            // 
            // myLabelReplie3
            // 
            this.myLabelReplie3.Location = new System.Drawing.Point(100, 185);
            this.myLabelReplie3.Name = "myLabelReplie3";
            this.myLabelReplie3.Size = new System.Drawing.Size(500, 60);
            this.myLabelReplie3.TabIndex = 7;
            this.myLabelReplie3.Text = "label4";
            // 
            // myLabelReplie4
            // 
            this.myLabelReplie4.Location = new System.Drawing.Point(100, 245);
            this.myLabelReplie4.Name = "myLabelReplie4";
            this.myLabelReplie4.Size = new System.Drawing.Size(500, 60);
            this.myLabelReplie4.TabIndex = 8;
            this.myLabelReplie4.Text = "label5";
            // 
            // myLabelPercent1
            // 
            this.myLabelPercent1.Location = new System.Drawing.Point(15, 65);
            this.myLabelPercent1.Name = "myLabelPercent1";
            this.myLabelPercent1.Size = new System.Drawing.Size(75, 65);
            this.myLabelPercent1.TabIndex = 9;
            this.myLabelPercent1.Text = "label1";
            // 
            // myLabelPercent2
            // 
            this.myLabelPercent2.Location = new System.Drawing.Point(15, 125);
            this.myLabelPercent2.Name = "myLabelPercent2";
            this.myLabelPercent2.Size = new System.Drawing.Size(75, 65);
            this.myLabelPercent2.TabIndex = 10;
            this.myLabelPercent2.Text = "label1";
            // 
            // myLabelPercent3
            // 
            this.myLabelPercent3.Location = new System.Drawing.Point(15, 185);
            this.myLabelPercent3.Name = "myLabelPercent3";
            this.myLabelPercent3.Size = new System.Drawing.Size(75, 65);
            this.myLabelPercent3.TabIndex = 11;
            this.myLabelPercent3.Text = "label1";
            // 
            // myLabelPercent4
            // 
            this.myLabelPercent4.Location = new System.Drawing.Point(15, 245);
            this.myLabelPercent4.Name = "myLabelPercent4";
            this.myLabelPercent4.Size = new System.Drawing.Size(75, 65);
            this.myLabelPercent4.TabIndex = 12;
            this.myLabelPercent4.Text = "label1";
            // 
            // myLabelResultHack
            // 
            this.myLabelResultHack.Location = new System.Drawing.Point(0, 378);
            this.myLabelResultHack.Name = "myLabelResultHack";
            this.myLabelResultHack.Size = new System.Drawing.Size(35, 35);
            this.myLabelResultHack.TabIndex = 13;
            this.myLabelResultHack.Click += new System.EventHandler(this.myLabelResultHack_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(633, 412);
            this.Controls.Add(this.myLabelResultHack);
            this.Controls.Add(this.myLabelPercent4);
            this.Controls.Add(this.myLabelPercent3);
            this.Controls.Add(this.myLabelPercent2);
            this.Controls.Add(this.myLabelPercent1);
            this.Controls.Add(this.myLabelReplie4);
            this.Controls.Add(this.myLabelReplie3);
            this.Controls.Add(this.myLabelReplie2);
            this.Controls.Add(this.myButtonNext);
            this.Controls.Add(this.myLabelReplie1);
            this.Controls.Add(this.myLabelQuestion);
            this.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label myLabelQuestion;
        private System.Windows.Forms.Label myLabelReplie1;
        private System.Windows.Forms.Button myButtonNext;
        private System.Windows.Forms.Label myLabelReplie2;
        private System.Windows.Forms.Label myLabelReplie3;
        private System.Windows.Forms.Label myLabelReplie4;
        private System.Windows.Forms.Label myLabelPercent1;
        private System.Windows.Forms.Label myLabelPercent2;
        private System.Windows.Forms.Label myLabelPercent3;
        private System.Windows.Forms.Label myLabelPercent4;
        private System.Windows.Forms.Label myLabelResultHack;
    }
}